# Installation Instructions

## Method One
In general we recommend just following the [Magento recommended
practice](https://devdocs.magento.com/cloud/howtos/install-components.html#install-an-extension) for
installing an extension. 

## Method Two
Alternatively you can downoad the latest version of the extension from our secure store [here]().

# Configuration
Please see the page specific configuration in `/view/frontend/templates`
